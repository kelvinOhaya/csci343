// This program shows an example of Open Record, all content are public!
// compiled with g++ -std=c++1z EmployeeRecord.h
// OpenRecord to store Employee Records.

#pragma once
#include <string>
#include <iostream>

using namespace std;

//
// Create EmployeeRecord
//
class EmployeeRecord
{
   // EEID,Full Name,Job Title,Gender,Age,Annual Salary,City,
public:
   string name;
   string address;
   string jobTitle;
   string gender;
   string city;
   int age;
   int salary;
   string zip;

   EmployeeRecord() : age(0), salary(0) {}
   ~EmployeeRecord() {}

   void clear(void)
   {
      name = "";
      address = "";
      jobTitle = "";
      gender = "";
      city = "";
      age = 0;
      salary = 0;
      zip = "";
   } // clear

   EmployeeRecord &operator=(EmployeeRecord &rhs)
   {
      name = rhs.name;
      address = rhs.address;
      jobTitle = rhs.jobTitle;
      city = rhs.city;
      age = rhs.age;
      salary = rhs.salary;
      zip = rhs.zip;

      return *this;
   } // operator =

   void transferFrom(EmployeeRecord &source)
   {
      name = source.name;
      address = source.address;
      jobTitle = source.jobTitle;
      city = source.city;
      age = source.age;
      salary = source.salary;
      zip = source.zip;
   } // transferFrom

   // overloading the output operator.The outputSequence function will make use
   // of this. Must be friend becuse EmployeeRecord is not primitive type.

   friend ostream &operator<<(ostream &os, EmployeeRecord &r)
   {
      os << "(" << r.name << "," << r.address << "," << r.jobTitle << "," << r.city << "," << r.age << "," << r.salary << "," << r.zip << ")";
      return os;
   } // operator <<
};

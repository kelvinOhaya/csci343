// author Dr.H on 10/25/2019
// compiled with g++ -std=c++1z driver.cpp
// This code read EmployeeRecords from a text file into a Sequence, then output the data.

#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <cctype>
#include "../../Kelvin Ohaya - C343-Assignment1/src/Sequence/Sequence.h"
#include "EmployeeRecord.h"

typedef Sequence<EmployeeRecord> EmployeeSequence;
typedef std::vector<EmployeeRecord *> EmployeeRecords;

EmployeeRecords eRecords;

// returns  vector of split words
auto split(const string &s, char delim)
{
    std::vector<string> out;
    std::string token;
    std::stringstream ss(s);
    while (std::getline(ss, token, delim))
    {
        out.push_back(token);
    }
    return out;
};

// CSV line parser that handles quoted fields and commas inside quotes
std::vector<std::string> parseCSVLine(const std::string &line)
{
    std::vector<std::string> fields;
    std::string cur;
    bool inQuotes = false;
    for (size_t i = 0; i < line.size(); ++i)
    {
        char c = line[i];
        if (inQuotes)
        {
            if (c == '"')
            {
                // look ahead for escaped quote
                if (i + 1 < line.size() && line[i + 1] == '"')
                {
                    cur.push_back('"');
                    ++i;
                }
                else
                {
                    inQuotes = false;
                }
            }
            else
            {
                cur.push_back(c);
            }
        }
        else
        {
            if (c == '"')
            {
                inQuotes = true;
            }
            else if (c == ',')
            {
                fields.push_back(cur);
                cur.clear();
            }
            else
            {
                cur.push_back(c);
            }
        }
    }
    fields.push_back(cur);
    return fields;
}

// parse salary string like "$141,604 " -> 141604
int parseSalary(const string &raw)
{
    string digits;
    for (char c : raw)
    {
        if (std::isdigit((unsigned char)c))
            digits.push_back(c);
    }
    if (digits.empty())
        return 0;
    try
    {
        return std::stoi(digits);
    }
    catch (...)
    {
        return 0;
    }
}

// returns the index where the smallest element based on salary is
// find index of minimum salary in pointerVector starting at 'start'
int findMinIndex(const EmployeeRecords &pointerVector, int start)
{
    int n = (int)pointerVector.size();
    if (n == 0 || start >= n)
        return -1;

    int minIndex = start;
    int currentSalary = pointerVector[start]->salary;
    for (int i = start + 1; i < n; ++i)
    {
        if (pointerVector[i]->salary < currentSalary)
        {
            minIndex = i;
            currentSalary = pointerVector[i]->salary;
        }
    }
    return minIndex;
}

void selectionSortVector(EmployeeRecords &pointerVector)
{
    // sort based on employee salary using selection sort
    int n = (int)pointerVector.size();
    for (int i = 0; i + 1 < n; ++i)
    {
        int minIndex = findMinIndex(pointerVector, i);
        if (minIndex >= 0 && minIndex != i)
        {
            auto temp = pointerVector[minIndex];
            pointerVector[minIndex] = pointerVector[i];
            pointerVector[i] = temp;
        }
    }
}

void doInputPersonDataFromFile(EmployeeSequence &personData, EmployeeRecords &pointerVector)
{
    string filename = "EmployeeSampleData/Employee Sample Data.csv";
    // file instream
    ifstream infile(filename);
    EmployeeRecord r;
    int dataSize;

    if (!infile)
    {
        cout << "Unable to open file";
        exit(1); // terminate with error
    }

    if (infile.is_open())
    {
        // Check for a first line
        string firstLine;
        if (!std::getline(infile, firstLine))
        {
            cout << "File is empty" << endl;
            return;
        }

        // If the first line looks like a header containing "EEID" treat as TSV or CSV with header
        bool isTSV = (firstLine.find('\t') != string::npos && firstLine.find("EEID") != string::npos);
        bool isCSV = (firstLine.find(',') != string::npos || firstLine.find('"') != string::npos) && firstLine.find("EEID") != string::npos;
        if (isTSV || isCSV)
        {
            // Read remaining lines and parse TSV columns
            string line;
            int count = 0;
            while (std::getline(infile, line))
            {
                if (line.empty())
                    continue;
                std::vector<string> cols;
                if (isTSV)
                    cols = split(line, '\t');
                else
                    cols = parseCSVLine(line);

                EmployeeRecord rec;
                // map commonly used columns: EEID, Full Name, Job Title, Department, Gender, Age, Annual Salary, City
                rec.name = cols[1];
                rec.salary = parseSalary(cols[6]);
                rec.city = cols[7]; // City is column 7, not 12
                rec.jobTitle = cols[2];
                rec.zip = "0";
                // Parse age from string to int (Age is column 5)
                try
                {
                    rec.age = stoi(cols[5]);
                }
                catch (...)
                {
                    rec.age = 0;
                }
                personData.add(rec, count);
                // allocate on heap so pointer remains valid after this loop iteration
                EmployeeRecord *heapRec = new EmployeeRecord(rec);
                pointerVector.push_back(heapRec);
                ++count;
            }
            cout << "Number of Records read (TSV): " << count << endl;
        }
        else
        {
            // Try to interpret the first line as the count (older format)
            std::stringstream ss(firstLine);
            if (ss >> dataSize)
            {
                cout << "Number of Records :" << dataSize << endl;
                for (int j = 0; j < dataSize; j++)
                {
                    EmployeeRecord rec;
                    if (!(infile >> rec.name))
                        break;
                    if (!(infile >> rec.address))
                        break;
                    if (!(infile >> rec.city))
                        break;
                    if (!(infile >> rec.zip))
                        break;
                    personData.add(rec, 0);
                } // end for
            }
            else
            {
                // Fallback: treat the file as lines of whitespace-separated records; include the first line
                // Put firstLine back into a stringstream and read tokens sequentially
                stringstream all;
                all << firstLine << '\n';
                string line;
                while (std::getline(infile, line))
                {
                    all << line << '\n';
                }
                int added = 0;
                while (all >> r.name >> r.address >> r.city >> r.zip)
                {
                    personData.add(r, 0);
                    ++added;
                }
                cout << "Number of Records read (fallback): " << added << endl;
            }
        }
        infile.close();
    } // end if

} // doInputPersonDataFromFile>

int main(int argc, char *argv[])
{

    EmployeeSequence eSequence;
    cout << "Reading EmployeeRecords from file" << endl;
    doInputPersonDataFromFile(eSequence, eRecords);
    selectionSortVector(eRecords);

    cout << "\nCompleted Reading, File contains following Employee Records" << endl;
    for (int i = 99; i >= 0; --i)
    {
        std::cout << (i + 1) << ": "
                  //   << "Name: " << eRecords[i]->name << std::endl
                  //   << "Address: " << eRecords[i]->address << std::endl
                  //   << "State: " << eRecords[i]->state << std::endl
                  //   << "Salary: " << eRecords[i]->salary << std::endl
                  //   << "Zip Code: " << eRecords[i]->zip << std::endl
                  //   << std::endl;
                  << *eRecords[i] << std::endl;
    }
    cout << endl;

    // free heap-allocated records
    for (auto p : eRecords)
        delete p;
    eRecords.clear();

    return 0;
}
